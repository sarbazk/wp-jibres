<?php
class TransStatic
{
 private function trans_static()
 {
	echo __("Jibres", 'jibres');
 }
}
?>