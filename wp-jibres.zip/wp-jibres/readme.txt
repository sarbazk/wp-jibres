=== wp-jibres ===
Contributors: jibres, MrJavadAdib, sarbazk
Donate link: https://jibres.com/
Tags: jibres, backup, back up, csv, api, transfer, jibres api, send to store, send to jibres
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 4.3
Requires PHP: 5.2.4
License: MIT License
License URI: https://mit-license.org/

Backup of all of your wordpress data and woocommerce into Jibres. Anytime you want you can transfer to Jibres. #1 World Sales Engineering System. Sell & Enjoy

== Description ==

If you have Jibres store or not can use this powerful plugin.
If you want to backup and save your data in your jibres store or csv files use this. the csv backups folder path is /plugins folder/this plugin folder(wp-jibres)/backup/
Or if you want to emigration to Jibres (#1 World Sales Engineering System. Sell & Enjoy) create your store in jibres and send all of your data to Jibres with a click in this plugin.
Backup speedly and beautiful with jibres plugin...

= Features =

*   Powerful and easy to use
*   Without setup required and force to set informations
*   Small space and big work
*   Works on any servers
*	Backup part of your data and all of it


= Help develop this plugin =

The Jibres plugin is hosted on GitHub, if you want to help out with development or testing then head over to https://github.com/jibres/wp-jibres/


== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to Jibres tab on your wordpress admin panel


== Frequently Asked Questions ==

**What jibres?**

For Sell and Enjoy :)
Jibres is the first sales engineering system in the world

**Can I use jibres plugin and I have not a jibres account?**

Yes...
Jibres plugin helping you to create your backup on your server by csv files. powerful, speedly, beautiful... 

== Screenshots ==

1. Jibres plugin for wordpress
2. Main page of Jibres plugin

== Changelog ==

= 1.1 =
* Changes code to standard wordpress code

= 1.0 =
* Create backup of orders, posts, comments and categories.
* Create backup of products.

== Upgrade Notice ==

= 1.0 =
Upgrade methods.


Here's a link to [WordPress](https://wordpress.org/plugins).
