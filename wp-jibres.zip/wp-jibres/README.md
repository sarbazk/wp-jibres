# wp-jibres
Jibres Plugin For Wordpress

Backup of all of your wordpress data and woocommerce into Jibres. Anytime you want you can transfer to Jibres. #1 World Sales Engineering System. Sell & Enjoy<br><br>

If you have jibres store or not can use this powerful plugin.<br>
If you want to backup and save your data in your jibres store or csv files use this. the csv backups folder path is /plugins folder/this plugin folder(wp-jibres)/backup/<br>
Or if you want to emigration to JIBRES (The first sales engineering system in the world) create your store in jibres and send all of your data to jibres with a click.<br>
Backup speedly and beautiful with jibres plugin...